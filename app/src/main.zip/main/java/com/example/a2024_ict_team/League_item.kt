package com.example.a2024_ict_team

data class LeagueItem(val name: String, val point: String, val rank: String)

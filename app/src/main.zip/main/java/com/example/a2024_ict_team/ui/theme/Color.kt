package com.example.a2024_ict_team.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFFF6D00)
val PurpleGrey80 = Color(0xFFFFA500)
val Pink80 = Color(0xFFFFD700)

val Purple40 = Color(0xFF9E9E9E)
val PurpleGrey40 = Color(0xFF424242)
val Pink40 = Color(0xFFA8E10C)